#include <stdio.h>

int main(int argc, char* argv[])
{
    printf("Hello world (version 1.0.0)\n");
    return 0;
}
